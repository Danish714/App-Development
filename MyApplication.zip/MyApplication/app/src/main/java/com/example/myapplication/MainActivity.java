package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {


    int count=0;
    TextView textView;
    Button button1;
    Button button2;
    Button ButtonReset;
    EditText editText;
    CheckBox checkBox;

    Button confirm;

    String name;
    TextView textViewBill;
    int burger = 250;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.textview);
        button1 = findViewById(R.id.btn1);
        button2 = findViewById(R.id.btn2);
        ButtonReset= findViewById(R.id.reset);
        editText = findViewById(R.id.name);
        checkBox = findViewById(R.id.mayo);
        confirm = findViewById(R.id.confirm);
        textViewBill = findViewById(R.id.txbill);



        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count++;
                textView.setText(String.valueOf(count));
                textViewBill.setText(String.valueOf(burger*count));

                Toast.makeText(MainActivity.this, "increment", Toast.LENGTH_SHORT).show();
            }

        });
        button2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count--;
                textView.setText(String.valueOf(count));
                textViewBill.setText(String.valueOf(burger*count));
                Toast.makeText(MainActivity.this, "decrement", Toast.LENGTH_SHORT).show();
            }
        });

        ButtonReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count = 0;
                textView.setText(String.valueOf(count));
                textViewBill.setText(String.valueOf(burger*count));
                editText.setText(" ");

                Toast.makeText(MainActivity.this, "reset", Toast.LENGTH_SHORT).show();
            }
        });

        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(count>0) {
                    name = editText.getText().toString();
                    Intent i = new Intent(MainActivity.this, newScreen.class);
                    i.putExtra("Name", name);
                    i.putExtra("Q", count);
                    i.putExtra("B", burger * count);
                    startActivity(i);
                }
                else
                {
                    Toast.makeText(MainActivity.this, "quantity cant be less than 0", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    }