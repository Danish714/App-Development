package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class newScreen extends AppCompatActivity {


    TextView textView;
    String name;
    String quantity, bill;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_screen);
        textView = findViewById(R.id.recipt);

        Intent i = getIntent();


        // Get the String value using the key "name"
        name = i.getStringExtra("Name");
        quantity = i.getStringExtra("Q");
        bill = i.getStringExtra("B");

        // Logging for debugging
        Log.d("Debug", "Name: " + name);
        Log.d("Debug", "Quantity: " + quantity);
        Log.d("Debug", "Bill: " + bill);



        textView.setText("Thanks for your order, Mr. " + name + "\n" +
                "Quantity: " + quantity + "\n" +
                "Bill: " + bill);



    }
}